import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-olvide',
  templateUrl: './olvide.page.html',
  styleUrls: ['./olvide.page.scss'],
})
export class OlvidePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
